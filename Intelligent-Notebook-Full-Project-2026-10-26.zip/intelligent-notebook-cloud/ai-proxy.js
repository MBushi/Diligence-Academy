// Intelligent Notebook server: local Ollama AI + server-side accounts, sessions and synced data.
// Single-instance starter. For a public production launch, move JSON storage to managed PostgreSQL.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

try {
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
} catch {}

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || (process.env.NODE_ENV === 'production' ? '0.0.0.0' : '127.0.0.1');
const OLLAMA_BASE_URL = (process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434').replace(/\/$/, '');
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3.2:3b';
const DB_FILE = path.join(__dirname, process.env.DATA_FILE || 'notebook-data.json');
const SESSION_MS = 30 * 24 * 60 * 60 * 1000;
const secureCookie = process.env.NODE_ENV === 'production';
const limits = new Map();
let db = { users: [], sessions: [], notebooks: {}, classes: {}, aiHistory: [] };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; } catch {}
function persist() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
}
function publicUser(u) { return { id: u.id, name: u.name, email: u.email, role: u.role }; }
function send(res, status, data, type = 'application/json; charset=utf-8', extra = {}) {
  res.writeHead(status, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', ...extra });
  res.end(typeof data === 'string' || Buffer.isBuffer(data) ? data : JSON.stringify(data));
}
function cookieValue(req, key) {
  const cookies = (req.headers.cookie || '').split(';');
  for (const part of cookies) { const i = part.indexOf('='); if (i > -1 && part.slice(0, i).trim() === key) return decodeURIComponent(part.slice(i + 1).trim()); }
  return '';
}
function cookieHeader(token, clear = false) {
  const value = clear ? '' : `nb_session=${encodeURIComponent(token)}`;
  return `${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${clear ? 0 : Math.floor(SESSION_MS / 1000)}${secureCookie ? '; Secure' : ''}`;
}
function currentUser(req) {
  const token = cookieValue(req, 'nb_session'); if (!token) return null;
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  const session = db.sessions.find(s => s.hash === hash && s.expires > Date.now());
  if (!session) return null;
  session.expires = Date.now() + SESSION_MS; // rolling 30-day login, until sign out/inactivity expiry
  const user = db.users.find(u => u.id === session.userId);
  if (user) persist();
  return user || null;
}
function limited(key, max = 20) {
  const now = Date.now(), recent = (limits.get(key) || []).filter(t => now - t < 60_000);
  if (recent.length >= max) { limits.set(key, recent); return true; }
  recent.push(now); limits.set(key, recent); return false;
}
async function readBody(req, maxBytes = 3_000_000) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (Buffer.byteLength(body, 'utf8') > maxBytes) throw Object.assign(new Error('Request is too large.'), { status: 413 });
  }
  try { return JSON.parse(body || '{}'); }
  catch { throw Object.assign(new Error('Invalid JSON request.'), { status: 400 }); }
}
function newId() { return crypto.randomBytes(16).toString('hex'); }
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (err, key) => err ? reject(err) : resolve(`${salt}:${key.toString('hex')}`)));
}
async function verifyPassword(password, stored) {
  const [salt, expectedHex] = String(stored || '').split(':'); if (!salt || !expectedHex) return false;
  const actual = await hashPassword(password, salt); const a = Buffer.from(actual.split(':')[1], 'hex'), b = Buffer.from(expectedHex, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function startSession(user) {
  const token = crypto.randomBytes(32).toString('base64url');
  db.sessions = db.sessions.filter(s => s.expires > Date.now());
  db.sessions.push({ hash: crypto.createHash('sha256').update(token).digest('hex'), userId: user.id, expires: Date.now() + SESSION_MS });
  persist(); return token;
}
function teacherSnapshot(user) {
  const users = [user, ...db.users.filter(u => u.role === 'student' && (db.notebooks[u.id] || []).some(b => b.teacher === user.id))];
  const notebooksByOwner = {};
  for (const student of users.filter(u => u.role === 'student')) notebooksByOwner[student.id] = (db.notebooks[student.id] || []).filter(b => b.teacher === user.id);
  return { user: publicUser(user), users: users.map(publicUser), notebooksByOwner, notebooks: [], classes: db.classes[user.id] || [] };
}
function syncSnapshot(user) {
  if (user.role === 'administrator') return teacherSnapshot(user);
  const teachers = db.users.filter(u => u.role === 'administrator').map(publicUser);
  return { user: publicUser(user), users: [...teachers, publicUser(user)], notebooksByOwner: { [user.id]: db.notebooks[user.id] || [] }, notebooks: db.notebooks[user.id] || [], classes: [] };
}
function cleanNotebookForStudent(book, oldBook, user) {
  if (!book || typeof book !== 'object' || typeof book.id !== 'string' || typeof book.title !== 'string' || !Array.isArray(book.pages)) return null;
  if (oldBook && oldBook.locked) return oldBook; // teacher locks are enforced on the server
  const copy = JSON.parse(JSON.stringify(book));
  copy.title = copy.title.slice(0, 200);
  copy.pages = copy.pages.slice(0, 100).map(p => ({ id: String(p.id || newId()).slice(0, 100), name: String(p.name || 'Page').slice(0, 200), html: String(p.html || '').slice(0, 1_000_000), ...(Array.isArray(p.history) ? { history: p.history.slice(-30) } : {}), ...(Array.isArray(p.lines) ? { lines: p.lines.slice(-500) } : {}) }));
  if (copy.teacher && !db.users.some(u => u.id === copy.teacher && u.role === 'administrator')) { delete copy.teacher; delete copy.status; }
  if (copy.teacher && (!oldBook || copy.teacher !== oldBook.teacher)) copy.status = 'pending';
  if (copy.teacher && oldBook && copy.teacher === oldBook.teacher) {
    copy.status = oldBook.status || copy.status || 'pending';
    if (oldBook.classId) copy.classId = oldBook.classId; else delete copy.classId;
  } else if (!copy.teacher) { delete copy.status; delete copy.classId; }
  copy.locked = false;
  return copy;
}
function safeEq(a, b) { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }

// Optional administrator bootstrap for a trusted owner account. Teachers can also self-register through the public signup form.
(async () => {
  const adminEmail = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD || '';
  if (adminEmail && adminPassword && !db.users.some(u => u.email === adminEmail)) {
    db.users.push({ id: newId(), name: process.env.ADMIN_NAME || 'Notebook Administrator', email: adminEmail, role: 'administrator', passwordHash: await hashPassword(adminPassword), createdAt: Date.now() });
    persist(); console.log(`Bootstrapped administrator account for ${adminEmail}`);
  }
})();

async function getOllamaTags() {
  const response = await fetch(`${OLLAMA_BASE_URL}/api/tags`, { signal: AbortSignal.timeout(4000) });
  if (!response.ok) throw new Error(`Ollama returned HTTP ${response.status}`);
  return response.json();
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'GET' && url.pathname === '/') {
      return fs.readFile(path.join(__dirname, 'intelligent-notebook.html'), (err, html) => err ? send(res, 500, 'intelligent-notebook.html not found next to ai-proxy.js', 'text/plain; charset=utf-8') : send(res, 200, html, 'text/html; charset=utf-8'));
    }
    if (req.method === 'GET' && url.pathname === '/health') {
      try {
        const tags = await getOllamaTags(); const models = Array.isArray(tags.models) ? tags.models.map(m => m.name || m.model).filter(Boolean) : [];
        const modelAvailable = models.some(n => n === OLLAMA_MODEL || n === `${OLLAMA_MODEL.split(':')[0]}:latest` && OLLAMA_MODEL.endsWith(':latest')) || models.some(n => n.split('/').pop() === OLLAMA_MODEL);
        return send(res, 200, { ok: true, provider: 'ollama-local', model: OLLAMA_MODEL, ollamaReachable: true, modelAvailable, installedModels: models, pullCommand: `ollama pull ${OLLAMA_MODEL}` });
      } catch { return send(res, 503, { ok: false, provider: 'ollama-local', model: OLLAMA_MODEL, ollamaReachable: false, error: 'Ollama is not reachable. Install Ollama and make sure it is running.' }); }
    }

    if (req.method === 'POST' && url.pathname === '/api/auth/signup') {
      if (limited(`signup:${req.socket.remoteAddress}`, 8)) return send(res, 429, { error: 'Too many attempts. Try again later.' });
      const input = await readBody(req, 20_000), name = String(input.name || '').trim(), email = String(input.email || '').trim().toLowerCase(), password = String(input.password || ''), confirmPassword = String(input.confirmPassword || '');
      if (!name || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return send(res, 400, { error: 'Enter a valid name and email address.' });
      if (password.length < 10) return send(res, 400, { error: 'Use a password with at least 10 characters.' });
      if (!confirmPassword || password !== confirmPassword) return send(res, 400, { error: 'The passwords do not match. Please re-enter them.' });
      const role = input.role === 'administrator' ? 'administrator' : 'student';
      if (db.users.some(u => u.email === email)) return send(res, 409, { error: 'That email already has an account. Sign in instead.' });
      // Public teacher registration is intentional. Teacher accounts are scoped: they can only
      // view/manage notebooks that students explicitly link to that teacher account.
      const user = { id: newId(), name, email, role, passwordHash: await hashPassword(password), createdAt: Date.now() };
      db.users.push(user); db.notebooks[user.id] = []; db.classes[user.id] = [];
      console.log(`Created ${role === 'administrator' ? 'teacher' : 'student'} account for ${email}.`);
      const token = startSession(user);
      return send(res, 201, { user: publicUser(user) }, 'application/json; charset=utf-8', { 'Set-Cookie': cookieHeader(token) });
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/signin') {
      if (limited(`signin:${req.socket.remoteAddress}`, 12)) return send(res, 429, { error: 'Too many sign-in attempts. Wait a minute and try again.' });
      const input = await readBody(req, 20_000), email = String(input.email || '').trim().toLowerCase(), password = String(input.password || ''), role = input.role === 'administrator' ? 'administrator' : 'student';
      const user = db.users.find(u => u.email === email && u.role === role);
      if (!user || !(await verifyPassword(password, user.passwordHash))) return send(res, 401, { error: 'Email or password is incorrect.' });
      const token = startSession(user);
      return send(res, 200, { user: publicUser(user) }, 'application/json; charset=utf-8', { 'Set-Cookie': cookieHeader(token) });
    }
    if (req.method === 'GET' && url.pathname === '/api/auth/session') {
      const user = currentUser(req); return user ? send(res, 200, { user: publicUser(user) }) : send(res, 401, { error: 'Not signed in.' });
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/signout') {
      const token = cookieValue(req, 'nb_session'), hash = token ? crypto.createHash('sha256').update(token).digest('hex') : '';
      db.sessions = db.sessions.filter(s => s.hash !== hash); persist();
      return send(res, 200, { ok: true }, 'application/json; charset=utf-8', { 'Set-Cookie': cookieHeader('', true) });
    }

    if (url.pathname.startsWith('/api/')) {
      const user = currentUser(req);
      if (!user) return send(res, 401, { error: 'Your session expired. Please sign in again.' });
      if (req.method === 'GET' && url.pathname === '/api/sync') return send(res, 200, syncSnapshot(user));
      if (req.method === 'GET' && url.pathname === '/api/ai-history') {
        const ownerId = String(url.searchParams.get('ownerId') || (user.role === 'student' ? user.id : ''));
        const notebookId = String(url.searchParams.get('notebookId') || '');
        if (!notebookId) return send(res, 400, { error: 'Choose a notebook to view its AI history.' });
        const books = db.notebooks[ownerId] || [];
        const book = books.find(b => b.id === notebookId);
        const allowed = user.role === 'student'
          ? ownerId === user.id && !!book
          : !!book && book.teacher === user.id && book.status !== 'pending' && book.status !== 'declined';
        if (!allowed) return send(res, 403, { error: 'You do not have permission to view AI history for this notebook.' });
        const entries = (db.aiHistory || []).filter(h => h.ownerId === ownerId && h.notebookId === notebookId).slice(-100).reverse();
        return send(res, 200, { entries, studentName: db.users.find(u => u.id === ownerId)?.name || 'Student', notebookTitle: book.title });
      }
      if (req.method === 'PUT' && url.pathname === '/api/sync') {
        const input = await readBody(req);
        if (user.role === 'student') {
          if (!Array.isArray(input.notebooks) || input.notebooks.length > 300) return send(res, 400, { error: 'Invalid notebook data.' });
          const old = db.notebooks[user.id] || [], next = [];
          for (const b of input.notebooks) {
            const previous = old.find(x => x.id === b.id);
            const cleaned = cleanNotebookForStudent(b, previous, user);
            if (cleaned) next.push(cleaned);
          }
          // Restore locked books even if a client attempts to delete them.
          for (const b of old) if (b.locked && !next.some(n => n.id === b.id)) next.push(b);
          db.notebooks[user.id] = next;
          return persistAndSync(res, user);
        }
        if (input.classes !== undefined) {
          if (!Array.isArray(input.classes) || input.classes.length > 200) return send(res, 400, { error: 'Invalid class data.' });
          db.classes[user.id] = input.classes.filter(c => c && typeof c.name === 'string').map(c => ({ id: String(c.id || newId()).slice(0, 100), name: c.name.slice(0, 100), teacher: user.id }));
        }
        if (input.notebooksByOwner && typeof input.notebooksByOwner === 'object') {
          for (const [ownerId, proposed] of Object.entries(input.notebooksByOwner)) {
            if (!Array.isArray(proposed) || proposed.length > 300) continue;
            const ownerUser = db.users.find(u => u.id === ownerId && u.role === 'student'); if (!ownerUser) continue;
            const stored = db.notebooks[ownerId] || [];
            for (const update of proposed) {
              const idx = stored.findIndex(b => b.id === update.id && b.teacher === user.id);
              if (idx < 0) continue;
              // A teacher may edit only notebooks explicitly linked to their account.
              const prior = stored[idx];
              const copy = JSON.parse(JSON.stringify(update));
              copy.id = prior.id; copy.teacher = user.id; copy.title = String(copy.title || prior.title).slice(0, 200);
              if (!Array.isArray(copy.pages)) copy.pages = prior.pages;
              copy.pages = copy.pages.slice(0, 100).map(p => ({ id: String(p.id || newId()).slice(0, 100), name: String(p.name || 'Page').slice(0, 200), html: String(p.html || '').slice(0, 1_000_000), ...(Array.isArray(p.history) ? { history: p.history.slice(-30) } : {}), ...(Array.isArray(p.lines) ? { lines: p.lines.slice(-500) } : {}) }));
              copy.locked = !!update.locked;
              const classExists = (db.classes[user.id] || []).some(c => c.id === update.classId);
              if (classExists) copy.classId = update.classId; else delete copy.classId;
              copy.status = ['active','pending','declined'].includes(update.status) ? update.status : prior.status;
              stored[idx] = copy;
            }
            db.notebooks[ownerId] = stored;
          }
        }
        return persistAndSync(res, user);
      }
      if (req.method === 'POST' && url.pathname === '/api/ai') {
        if (limited(`ai:${user.id}`, 30)) return send(res, 429, { error: 'Too many AI requests. Try again in a minute.' });
        const input = await readBody(req, 1_000_000), system = typeof input.system === 'string' ? input.system.slice(0, 20_000).trim() : '', messages = Array.isArray(input.messages) ? input.messages : null;
        if (!system || !messages || messages.length < 1 || messages.length > 10 || messages.some(m => !m || !['user','assistant'].includes(m.role) || typeof m.content !== 'string')) return send(res, 400, { error: 'Invalid AI request. Provide a system prompt and valid messages.' });
        const raw = Number(input.max_tokens || 450), maxTokens = Number.isFinite(raw) ? Math.max(1, Math.min(Math.floor(raw), 900)) : 450;
        const notebookId = String(input.notebookId || '').slice(0, 120);
        const ownerId = String(input.ownerId || (user.role === 'student' ? user.id : '')).slice(0, 120);
        const historyLabel = String(input.historyLabel || 'AI tutor').slice(0, 80);
        let historyContext = null;
        if (notebookId && ownerId) {
          const book = (db.notebooks[ownerId] || []).find(b => b.id === notebookId);
          const allowed = user.role === 'student'
            ? ownerId === user.id && !!book
            : !!book && book.teacher === user.id && book.status !== 'pending' && book.status !== 'declined';
          if (allowed) historyContext = { ownerId, notebookId, notebookTitle: book.title };
        }
        // Check availability first so the UI gets an actionable error instead of a generic model failure.
        let tags;
        try { tags = await getOllamaTags(); }
        catch { return send(res, 503, { error: `Cannot connect to Ollama at ${OLLAMA_BASE_URL}. Open Ollama from the Windows Start menu, then check http://localhost:3000/health.` }); }
        const installed = Array.isArray(tags.models) ? tags.models.map(m => m.name || m.model).filter(Boolean) : [];
        const modelAvailable = installed.some(n => n === OLLAMA_MODEL || (OLLAMA_MODEL.endsWith(':latest') && n === `${OLLAMA_MODEL.split(':')[0]}:latest`));
        if (!modelAvailable) return send(res, 503, { error: `The required model '${OLLAMA_MODEL}' is not installed. In a terminal where Ollama works, run: ${`ollama pull ${OLLAMA_MODEL}`}. Then retry the AI tutor.` });
        let upstream;
        try {
          upstream = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
            method: 'POST', headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ model: OLLAMA_MODEL, messages: [{ role: 'system', content: system }, ...messages.map(m => ({ role: m.role, content: m.content.slice(0, 18_000) }))], stream: true, keep_alive: '30m', options: { num_predict: maxTokens, num_ctx: 4096, temperature: 0.2 } }),
            signal: AbortSignal.timeout(180_000)
          });
        } catch (err) { return send(res, 503, { error: err && err.name === 'TimeoutError' ? 'The local AI took too long to respond. Try again or use a smaller model.' : `Cannot connect to Ollama. Open Ollama and ensure model ${OLLAMA_MODEL} is installed.` }); }
        if (!upstream.ok) {
          const txt = await upstream.text(); let result; try { result = JSON.parse(txt); } catch { result = {}; }
          return send(res, upstream.status, { error: result.error || `Ollama request failed (HTTP ${upstream.status}).` });
        }
        // Relay Ollama's NDJSON stream immediately so the tutor can show words as they arrive.
        res.writeHead(200, { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', 'X-Accel-Buffering': 'no' });
        let pendingLine = '', answer = '';
        try {
          for await (const chunk of upstream.body) {
            const piece = Buffer.from(chunk).toString('utf8');
            res.write(piece);
            pendingLine += piece;
            const lines = pendingLine.split('\n'); pendingLine = lines.pop() || '';
            for (const line of lines) {
              if (!line.trim()) continue;
              try { const item = JSON.parse(line); answer += item.message?.content || ''; } catch {}
            }
          }
          if (pendingLine.trim()) { try { const item = JSON.parse(pendingLine); answer += item.message?.content || ''; } catch {} }
          res.end();
          if (historyContext && answer.trim()) {
            db.aiHistory = Array.isArray(db.aiHistory) ? db.aiHistory : [];
            const prompt = messages.map(m => `${m.role}: ${m.content}`).join('\n\n').slice(0, 6000);
            db.aiHistory.push({ id: newId(), ownerId: historyContext.ownerId, notebookId: historyContext.notebookId, notebookTitle: historyContext.notebookTitle, studentName: db.users.find(u => u.id === historyContext.ownerId)?.name || 'Student', actorId: user.id, actorName: user.name, actorRole: user.role, label: historyLabel, prompt, answer: answer.trim().slice(0, 12000), createdAt: Date.now() });
            // Bound the local JSON database so AI logs cannot grow without limit.
            if (db.aiHistory.length > 5000) db.aiHistory = db.aiHistory.slice(-5000);
            const sameBook = db.aiHistory.filter(h => h.ownerId === historyContext.ownerId && h.notebookId === historyContext.notebookId);
            if (sameBook.length > 200) {
              const remove = new Set(sameBook.slice(0, sameBook.length - 200).map(h => h.id));
              db.aiHistory = db.aiHistory.filter(h => !remove.has(h.id));
            }
            persist();
          }
        } catch (err) {
          console.error('AI stream error:', err.message);
          if (!res.writableEnded) res.end();
        }
        return;
      }
    }
    return send(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('Request error:', err && err.message ? err.message : err);
    return send(res, err.status || 500, { error: err.status ? err.message : 'The server could not complete that request.' });
  }
});
function persistAndSync(res, user) { persist(); return send(res, 200, syncSnapshot(user)); }
server.listen(PORT, HOST, () => {
  console.log(`Notebook server listening at http://${HOST}:${PORT}`);
  console.log(`Local AI model: ${OLLAMA_MODEL}`);
  console.log(`Data file: ${DB_FILE}`);
  if (!secureCookie) console.log('Development mode: session cookies are not Secure. Set NODE_ENV=production behind HTTPS when deployed.');
});
