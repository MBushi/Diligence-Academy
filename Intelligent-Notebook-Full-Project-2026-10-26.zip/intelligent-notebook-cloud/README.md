# Intelligent Notebook — server accounts + cross-device sync

This version replaces browser-only account credentials with server-side accounts, hashed passwords, HTTP-only session cookies, and server-stored notebook data. The same account can sign in on multiple devices. Sessions persist across refreshes and browser restarts for up to 30 days of activity, and signing out revokes the current device's session.

## Local development

1. Install Node.js 18 or newer: https://nodejs.org/
2. Install Ollama: https://ollama.com/download
3. Download the local AI model once:

   ```powershell
   ollama pull llama3.2:3b
   ```

4. Copy `.env.example` to `.env` if you want to configure the model or optionally bootstrap a trusted owner account.
5. Start the app:

   ```powershell
   npm start
   ```

   If PowerShell blocks `npm.ps1`, use `npm.cmd start` instead. Keep this terminal open while using the notebook.

6. Open http://localhost:3000. Do not use Live Server or open the HTML file directly.

When creating an account, enter the same password in both password fields. The server also checks that the passwords match, so skipping browser validation will not bypass this check. Password reset is not configured because no email provider is connected; do not use real school accounts until a secure recovery process is set up.

### If the app says it cannot reach the notebook server

- Keep the terminal running after `npm start`; it should print `Notebook server listening at http://127.0.0.1:3000` (or the configured host/port).
- Open exactly http://localhost:3000 in the same browser, not the HTML file, Live Server, or another port.
- If the terminal reports `EADDRINUSE`, another program is using port 3000. Stop the other notebook server or choose a different `PORT` and open that port.
- If the browser still cannot connect, read the full error shown on the sign-in page and the server terminal output.

## Student and teacher accounts

Students and teachers can both create their own accounts from the sign-up screen. Choose **Student** for a student notebook account or **Teacher** for the teacher tools. You do not need to configure an administrator in `.env` just to let a teacher sign up. The internal role name for teacher accounts remains `administrator` for compatibility with the app.

Teacher accounts are scoped: a teacher only receives student notebooks that students explicitly link to that teacher, and the server checks the teacher ID before allowing notebook management. However, public teacher sign-up does not verify that someone is actually a teacher. For a real school deployment, add school email verification or invite codes before allowing public teacher registration.

Optionally, a trusted site owner can still bootstrap a known administrator account by setting `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and `ADMIN_NAME` in `.env` before startup. This is optional and not required for ordinary teacher accounts. Keep `.env` private.

## How syncing works

- The server stores account records, password hashes, session-token hashes, notebooks, and classes in `notebook-data.json` next to `ai-proxy.js`.
- The browser uses local storage as a cache, but the server is the source of truth when signing in and syncing.
- Notebook edits sync automatically after a short delay. The editor's save indicator changes to `Synced` when the server confirms a sync.
- Teacher operations are checked server-side: teachers only receive notebooks linked to their own teacher account, and only the linked teacher can change their management settings. Student changes cannot remove a server-locked notebook.
- Passwords are hashed using Node's scrypt. Session IDs are random tokens stored as hashes on the server and sent as `HttpOnly`, `SameSite=Lax` cookies.

## Using it on multiple devices

`localhost` is only the computer running the app. To sync from another device, deploy the server to a host with **HTTPS and persistent disk storage** and use the same hosted URL on each device. Set `NODE_ENV=production` behind HTTPS so cookies use the `Secure` attribute. Do not deploy this JSON-file version as multiple server instances: it is designed for one server process with one persistent data volume. Back up `notebook-data.json` regularly.

**Local AI deployment note:** Ollama must be running on the same host as the notebook server (or `OLLAMA_BASE_URL` must point to a private, protected Ollama service). If you host the web app online but keep Ollama only on your own PC, other devices/users cannot use that PC's local model through the hosted app. Local model use also requires enough RAM/storage on the host.

## Important limitations before a real public launch

This is a single-instance starter, not yet a production student information system. For a real school-wide launch, move persistence to managed PostgreSQL or another database designed for concurrent writes, add email verification and a real password-reset provider, audit logging, stronger request/CSRF protections, backups/restore tests, privacy/retention policies, and a security review. Do not store real student records until those steps are complete. The JSON data file contains private account and notebook data and must never be committed to Git or served as a static file.

## AI troubleshooting and health check

- The **AI status & help** button in the editor reports whether Ollama is reachable and whether the configured model is installed, with plain-language next steps.
- `GET /health` reports Ollama reachability, the exact configured model, and the installed model list. A `503` means Ollama is unreachable; sign-in and notebook syncing can still work.
- If the model is missing, open a terminal where the `ollama` command works and run `ollama pull llama3.2:3b` (or the model configured in `.env`).
- If `ollama` works in regular PowerShell but not VS Code, fully close and reopen VS Code so its integrated terminal refreshes its PATH. Ollama itself can normally run as a background service; `ollama run llama3.2:3b` is only a useful interactive test, not a required permanent second process.
- `GET /api/auth/session` reports whether the current browser has a valid server session.
- AI responses stream into the tutor as they are generated, so users see the answer begin before generation is complete. The model is kept loaded for about 30 minutes after use, context is capped to reduce slow requests, and ordinary responses have a lower output-token limit. The first answer after a restart can still take longer because the local model needs to warm up.
- Teachers can open a linked notebook and use **AI history** in the editor toolbar to review the most recent prompts and AI responses. History is stored in `notebook-data.json`, limited to 200 entries per notebook and 5,000 total. Students see a notice that teachers linked to a notebook can review its AI activity. Prompts may include note text, so do not enter sensitive personal information.
- The AI endpoint validates request shape, limits request size and token output, rate-limits calls, and returns actionable errors for missing models or an unreachable Ollama service.

## Sign-in repair included in this build

The sign-in screen's JavaScript selector for the AI status button has been corrected. Previously, that selector returned `null` and threw an error while the page initialized, preventing the remaining sign-in and sign-up click handlers from being registered. This build has been checked in a browser for startup JavaScript errors and for the Create account toggle and form validation.

When updating an existing installation, stop the server first and back up `notebook-data.json` and `.env`. This source ZIP intentionally does not include either file. Copy the included application files over the old source files, but keep your original `notebook-data.json` and `.env` unchanged.


## Final pre-submission notes

- The sign-up, sign-in, sign-out, and authenticated notebook-sync paths were smoke-tested locally. AI generation still requires Ollama and the configured local model to be running.
- Password recovery is intentionally marked as not configured. A real reset requires server-generated, expiring, single-use tokens and a configured email provider; the browser must not pretend to reset the server password.
- Before replacing an existing installation, back up `notebook-data.json` and `.env`. Do not copy a new/empty data file over your existing one.
- This is a local development/demo server using JSON storage, not a hardened public production deployment. Keep it local for the demo unless you separately configure HTTPS, production session cookies, and durable database storage.
- For the Congressional App Challenge, record a demo only after manually testing sign-up, sign-in, notebook saving, teacher permissions, and the AI tutor on the computer you will use to present.
